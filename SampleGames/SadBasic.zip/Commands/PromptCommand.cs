﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using SadConsole;
using Console = SadConsole.Console;

namespace SadConsole.Text.Commands
{
    public class PromptCommand : ICommandProcessor
    {
        Cursor virtualCursor;
        TextConsole console;
        Point cursorStartPoint;
        Point cursorEndPoint;
        bool freeMove;
        bool insertMode;


        public bool Completed { get; private set; }

        public void Tick(TimeSpan delta)
        {

        }

        public void Start(TextConsole console, string parameters)
        {
            virtualCursor = console.VirtualCursor;
            this.console = console;
            NewPrompt();
        }

        public void Stop()
        {
            virtualCursor = null;
            console = null;
        }

        public void Resume()
        {
            NewPrompt();
        }

        public void Pause()
        {
        }

        public bool KeyboardInput(SadConsole.Input.Keyboard info)
        {
            // Moving the cursor around
            if (//freeMove ||
                info.IsKeyPressed(Keys.Left) ||
                info.IsKeyPressed(Keys.Right) ||
                info.IsKeyPressed(Keys.Up) ||
                info.IsKeyPressed(Keys.Down))
            {
                if (info.IsKeyPressed(Keys.Left))
                {
                    if (cursorStartPoint == virtualCursor.Position)
                    {
                        return false;
                    }
                    else
                    {
                        virtualCursor.LeftWrap(1);
                        return true;
                    }

                }
                else if (info.IsKeyPressed(Keys.Right))
                {
                    if (virtualCursor.Position == cursorEndPoint)
                    {
                        return false;
                    }
                    else
                    {
                        virtualCursor.RightWrap(1);
                        return true;
                    }
                }

                return false;
            }

            foreach (var key in info.KeysPressed)
            {
                if (key.Character == '\0')
                {
                    switch (key.Key)
                    {
                        case Keys.Space:
                            InsertOrPrint(" ");
                            didSomething = true;
                            break;
                        case Keys.Enter:
                            ProcessCommandString(GetText());
                            didSomething = true;
                            break;
                        case Keys.Delete:
                            if (virtualCursor.Position == cursorStartPoint || virtualCursor.Position == cursorEndPoint)
                                return false;

                            RemoveCurrentCharacter();
                            didSomething = true;
                            break;
                        case Keys.Back:
                            if (virtualCursor.Position == cursorStartPoint)
                                return false;

                            virtualCursor.LeftWrap(1);
                            RemoveCurrentCharacter();
                            break;
                    }
                }
                else
                {
                    InsertOrPrint(key.Character.ToString());
                    didSomething = true;

                    if (console.TimesShiftedUp != 0)
                    {
                        cursorStartPoint.Y -= console.TimesShiftedUp;
                        console.TimesShiftedUp = 0;
                    }
                }
            }

            return didSomething;
        }

        private void ProcessCommandString(string commandString)
        {
            virtualCursor.CarriageReturn().LineFeed();

            string[] parts = commandString.Split(new char[] { ' ' }, 2);
            string key = parts[0].ToLower();
            if (console.KnownCommands.ContainsKey(key))
            {
                var cmd = console.KnownCommands[key];
                console.PushCommand(cmd, parts.Length != 1 ? parts[1] : "");
            }
            else
            {
                console.PushCommand(new PrintError("Invalid command"));
            }
        }

        private void InsertOrPrint(string text)
        {
            bool adding = cursorEndPoint == virtualCursor.Position;

            if (insertMode)
            {
                if (adding)
                {
                    virtualCursor.Print(text);
                    SetCursorEnd(virtualCursor.Position);
                }
                else
                {
                    for (int i = cursorEndPoint.ToIndex(console.Width); i > virtualCursor.Position.ToIndex(console.Width); i--)
                    {
                        Point pos = console.TextSurface.GetPointFromIndex(i);
                        Point pos2 = console.TextSurface.GetPointFromIndex(i - 1);
                        console.SetGlyph(pos.X, pos.Y, console.GetGlyph(pos2.X, pos2.Y));
                    }

                    virtualCursor.Print(text);
                    SetCursorEnd(console.TextSurface.GetPointFromIndex(cursorEndPoint.ToIndex(console.Width) + 1));
                }
            }
            else
            {
                if (adding)
                {
                    virtualCursor.Print(text);
                    SetCursorEnd(virtualCursor.Position);
                }
                else
                {
                    virtualCursor.Print(text);
                }
            }

        }

        private void RemoveCurrentCharacter()
        {
            console.SetGlyph(virtualCursor.Position.X, virtualCursor.Position.Y, ' ');

            for (int i = virtualCursor.Position.ToIndex(console.Width); i < cursorEndPoint.ToIndex(console.Width); i++)
            {
                Point pos = console.TextSurface.GetPointFromIndex(i);
                Point pos2 = console.TextSurface.GetPointFromIndex(i + 1);
                console.SetGlyph(pos.X, pos.Y, console.GetGlyph(pos2.X, pos2.Y));
            }

            TrimEndPoint();
        }

        bool didSomething;

        public void SetCursorEnd(Point position)
        {
            // Debug
            //console.SetBackground(cursorEndPoint.X, cursorEndPoint.Y, Color.Black);

            cursorEndPoint = position;

            // Debug
            //console.SetBackground(cursorEndPoint.X, cursorEndPoint.Y, Color.Red);
        }

        public void NewPrompt()
        {
            virtualCursor.NewLine().Print("SadConsole> ");
            cursorStartPoint = virtualCursor.Position;
            SetCursorEnd(cursorStartPoint);
            console.TimesShiftedUp = 0;
        }

        public void TrimEndPoint()
        {
            int index = cursorEndPoint.ToIndex(console.Width);
            int length = index - cursorStartPoint.ToIndex(console.Width);

            if (length > 0)
            {
                string text = console.GetString(cursorStartPoint.ToIndex(console.Width), length).TrimEnd(' ').TrimEnd('\0');

                if (text.Length == 0)
                    SetCursorEnd(virtualCursor.Position);
                else
                    SetCursorEnd(console.TextSurface.GetPointFromIndex(cursorStartPoint.ToIndex(console.Width) + text.Length));
            }
            else
                SetCursorEnd(virtualCursor.Position);
        }

        public string GetText()
        {
            int length = cursorEndPoint.ToIndex(console.Width) - cursorStartPoint.ToIndex(console.Width);

            if (length > 0)
                return console.GetString(cursorStartPoint.ToIndex(console.Width), length);

            return "";
        }

    }
}
