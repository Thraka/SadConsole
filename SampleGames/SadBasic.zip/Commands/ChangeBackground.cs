﻿using Microsoft.Xna.Framework;
using SadConsole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadConsole.Text.Commands
{
    public class ChangeBackground : ICommandProcessor
    {
        public bool Completed { get; private set; }

        public bool KeyboardInput(SadConsole.Input.Keyboard info)
        {
            return false;
        }

        public void Pause()
        {
        }

        public void Resume()
        {
        }

        public void Start(TextConsole console, string parameters)
        {
            Completed = false;

            if (TryFindColor(parameters, out Color color))
            {
                console.VirtualCursor.PrintAppearance.Background = color;
                console.TextSurface.DefaultBackground = color;
                foreach (var cell in console.TextSurface.Cells)
                    cell.Background = color;
            }
            else
            {
                console.PushCommand(new PrintError("Invalid color"));
            }

            Completed = true;
        }

        private bool TryFindColor(string parameters, out Color color)
        {
            color = new Color();
            try
            {
                color = color.FromParser(parameters, out bool keepR, out bool keepG, out bool keepB, out bool keepA, out bool useDefault);
                return true;
            }
            catch (Exception)
            {
            }

            return false;
        }

        public void Stop()
        {
        }

        public void Tick(TimeSpan delta)
        {
        }
    }
}
