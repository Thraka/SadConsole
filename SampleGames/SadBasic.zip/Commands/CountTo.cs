﻿using SadConsole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadConsole.Text.Commands
{
    public class CountTo : ICommandProcessor
    {
        public bool Completed { get; private set; }

        private int currentSeconds = 1;
        private int goalSeconds = 0;
        private TimeSpan timePassed = new TimeSpan();
        private Cursor virtualCursor;

        public bool KeyboardInput(SadConsole.Input.Keyboard info)
        {
            return false;
        }

        public void Pause()
        {
        }

        public void Resume()
        {
        }

        public void Start(TextConsole console, string parameters)
        {
            // Reset state
            Completed = false;
            currentSeconds = 1;

            // Validate the params
            if (int.TryParse(parameters, out goalSeconds))
            {
                if (goalSeconds <= 0)
                {
                    console.PushCommand(new PrintError("Seconds must be greater than 0"));
                    Completed = true;
                }
                else
                    virtualCursor = console.VirtualCursor;
            }
            else
            {
                console.PushCommand(new PrintError("Invalid number"));
                Completed = true;
            }
        }

        public void Stop()
        {
            virtualCursor = null;
        }

        public void Tick(TimeSpan delta)
        {
            // Track how much time has passed.
            timePassed += delta;

            // If we've gone over a second, display the counter.
            if (timePassed.Seconds >= 1)
            {
                timePassed = TimeSpan.Zero;
                virtualCursor.Print($"{currentSeconds}...");
                currentSeconds++;

                // If we reached the goal seconds, mark as completed.
                if (currentSeconds > goalSeconds)
                {
                    virtualCursor.Print("Done!").NewLine();
                    Completed = true;
                }
            }
        }
    }
}
