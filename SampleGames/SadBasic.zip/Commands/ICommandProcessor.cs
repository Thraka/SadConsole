﻿using System;
using SadConsole;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadConsole.Text.Commands
{
    /// <summary>
    /// Represents a command to run. Commands can finish instantly or continue to run over multiple frames.
    /// </summary>
    public interface ICommandProcessor
    {
        /// <summary>
        /// Flags the command as finished.
        /// </summary>
        bool Completed { get; }

        /// <summary>
        /// Called every update frame.
        /// </summary>
        /// <param name="delta">Time since last update.</param>
        void Tick(TimeSpan delta);

        /// <summary>
        /// If the command is the active command, any keyboard input is sent here.
        /// </summary>
        /// <param name="info">Keyboard state.</param>
        /// <returns>Return false if we didn't do anything with the input.</returns>
        bool KeyboardInput(SadConsole.Input.Keyboard info);

        /// <summary>
        /// Called when the command becomes active.
        /// </summary>
        /// <param name="console">The parent console running the command.</param>
        /// <param name="parameters">The parameters allocated to the command.</param>
        void Start(TextConsole console, string parameters);

        /// <summary>
        /// Called when the command is stopped.
        /// </summary>
        void Stop();

        /// <summary>
        /// Called when the command is still alive but is no longer the active command (some new command came through)
        /// </summary>
        void Pause();

        /// <summary>
        /// Called when the command is still alive and is now back to being the active command.
        /// </summary>
        void Resume();
    }
}
