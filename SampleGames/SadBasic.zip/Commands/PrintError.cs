﻿using Microsoft.Xna.Framework;
using SadConsole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadConsole.Text.Commands
{
    public class PrintError : ICommandProcessor
    {
        public bool Completed { get; private set; }

        private string message;

        public PrintError(string message) => this.message = message;

        public bool KeyboardInput(SadConsole.Input.Keyboard info) => false;

        public void Pause()
        {
        }

        public void Resume()
        {
        }

        public void Start(TextConsole console, string parameters)
        {
            Completed = false;
            console.VirtualCursor.Print($"ERROR: {message}".CreateColored(Color.Red)).NewLine();
            Completed = true;
        }

        public void Stop()
        {
        }

        public void Tick(TimeSpan delta)
        {
        }
    }
}
