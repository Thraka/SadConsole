﻿using SadConsole;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SadConsole.Text.Commands
{
    public class EchoCommand : ICommandProcessor
    {
        public bool Completed { get; private set; }

        public bool KeyboardInput(SadConsole.Input.Keyboard info)
        {
            return false;
        }

        public void Pause()
        {
        }

        public void Resume()
        {
        }

        public void Start(TextConsole console, string parameters)
        {
            Completed = false;
            console.VirtualCursor.Print(parameters).NewLine();
            Completed = true;
        }

        public void Stop()
        {
        }

        public void Tick(TimeSpan delta)
        {
        }
    }
}
