﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SadConsole.Text.Commands;
using Console = SadConsole.Console;
using Microsoft.Xna.Framework;

namespace SadConsole
{
    /// <summary>
    /// Console that simulates a text prompt (or any sort of command processing text system)
    /// </summary>
    public class TextConsole : Console
    {
        /// <summary>
        /// The known commands to this console.
        /// </summary>
        public Dictionary<string, ICommandProcessor> KnownCommands = new Dictionary<string, ICommandProcessor>();

        /// <summary>
        /// Current commands being processed.
        /// </summary>
        public Stack<ICommandProcessor> Commands = new Stack<ICommandProcessor>();

        public TextConsole(int width, int height) : base(width, height)
        {
            virtualCursor.IsVisible = true;
            virtualCursor.DisableWordBreak = true;

            textSurface.DefaultForeground = ColorAnsi.White;
            virtualCursor.PrintAppearance.Foreground = ColorAnsi.White;
            virtualCursor.CursorRenderCell.Foreground = ColorAnsi.WhiteBright;
            virtualCursor.CursorRenderCell.Glyph = '_'; // Or for different look: 22;

            RegisterCommand(new CountTo(), "count", "countto");     //count 5
            RegisterCommand(new EchoCommand(), "echo", "print");    //echo This is text to reprint!
            RegisterCommand(new ChangeBackground(), "background");  //background blue 
                                                                    //background 172,44,123

            // We don't register the "PromptCommand" because it's a "root" processor that is 
            // always there. We don't want someone creating more of it. Maybe there is a case for that though.. but work around that then :)
            PushCommand(new PromptCommand());
        }

        /// <summary>
        /// Wrapper method for adding a single command with multiple names to <see cref="KnownCommands"/>.
        /// </summary>
        /// <param name="command">The command to add.</param>
        /// <param name="names">One or more names to find the command by.</param>
        public void RegisterCommand(ICommandProcessor command, params string[] names)
        {
            foreach (var name in names)
                KnownCommands.Add(name.ToLower().Trim(), command);
        }


        public override bool ProcessKeyboard(SadConsole.Input.Keyboard info)
        {
            // Send keyboard info to the active command.
            Commands.Peek().KeyboardInput(info);

            // return true, we dont want other consoles in sadconsole doing things with our input.
            return true;
        }

        /// <summary>
        /// The normal "every frame" update loop.
        /// </summary>
        /// <param name="delta"></param>
        public override void Update(TimeSpan delta)
        {
            base.Update(delta);

            // Get the next valid command (remove any finished) and "Tick" it.
            var command = Commands.Peek();
            var needsResume = false;
            while (command.Completed)
            {
                needsResume = true;
                PopCommand();
                command = Commands.Peek();
            }

            // We cleared some finished commands. They would have called Pause() on our command so call Resume()
            if (needsResume)
                command.Resume();

            // Normal tick for any command that didn't finish.
            command.Tick(delta);

            // If the comamnd is finshed, remove it. If some other command became active (was pushed), do nothing.
            if (command.Completed && Commands.Peek() == command)
            {
                PopCommand();
            }
        }

        /// <summary>
        /// Set a new active command.
        /// </summary>
        /// <param name="processor">The command.</param>
        /// <param name="parameters">Any parameters sent to the command.</param>
        public void PushCommand(ICommandProcessor processor, string parameters = "")
        {
            ICommandProcessor oldProcessor = null;

            
            // If there is an existing command, pause it.
            if (Commands.Count != 0)
            {
                // This command is already on top, do nothing.
                if (processor == Commands.Peek())
                    return;

                oldProcessor = Commands.Peek();
                oldProcessor.Pause();
            }

            // Start the new command.
            Commands.Push(processor);
            processor.Start(this, parameters);

            // Check if finished and still the active guy
            if (processor.Completed && processor == Commands.Peek())
            {
                // Quick finish, remove
                PopCommand();
            }
        }

        /// <summary>
        /// Gets rid of the existing command.
        /// </summary>
        /// <returns>The current command removed from the stack.</returns>
        public ICommandProcessor PopCommand()
        {
            // Stop the existing command and resume the previous command.
            ICommandProcessor command = Commands.Pop();
            command.Stop();
            Commands.Peek().Resume();
            return command;
        }
    }
}
