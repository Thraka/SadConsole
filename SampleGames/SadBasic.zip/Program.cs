﻿using SadConsole.Input;
using System;
using Console = SadConsole.Console;
using SadConsole;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using SadConsole.Text;
using SadConsole.Text.Commands;
using Microsoft.Xna.Framework;

namespace SadPrompt
{
    /// <summary>
    /// The main class.
    /// </summary>
    class Program
    {
        public const int ScreenWidth = 80;
        public const int ScreenHeight = 25;

        private static void Main(string[] args)
        {
            // Setup the engine and create the main window.
            SadConsole.Game.Create("IBM.font", ScreenWidth, ScreenHeight);

            // Hook the start event so we can add consoles to the system.
            SadConsole.Game.OnInitialize = Init;

            // Hook the update event that happens each frame so we can trap keys and respond.
            SadConsole.Game.OnUpdate = Update;

            // Start the game.
            SadConsole.Game.Instance.Run();

            //
            // Code here will not run until the game window closes.
            //

            SadConsole.Game.Instance.Dispose();
        }

        private static void Update(GameTime time)
        {
            // Called each logic update.

            // As an example, we'll use the F5 key to make the game full screen
            if (SadConsole.Global.KeyboardState.IsKeyReleased(Microsoft.Xna.Framework.Input.Keys.F5))
            {
                SadConsole.Settings.ToggleFullScreen();
            }
            else if (SadConsole.Global.KeyboardState.IsKeyReleased(Microsoft.Xna.Framework.Input.Keys.Escape))
            {
                SadConsole.Game.Instance.Exit();
            }
        }

        private static void Init()
        {
            SadConsole.Global.CurrentScreen = new TextConsole(ScreenWidth, ScreenHeight);
            SadConsole.Global.FocusedConsoles.Set((TextConsole)SadConsole.Global.CurrentScreen);
        }

    }
}